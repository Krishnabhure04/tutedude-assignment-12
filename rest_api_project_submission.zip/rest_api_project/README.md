REST API Project (Assignment 7)

Run:
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py runserver

API: /api/students/
